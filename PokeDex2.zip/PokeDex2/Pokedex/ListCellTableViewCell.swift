//
//  ListCellTableViewCell.swift
//  Pokedex
//
//  Created by Jessica Chen on 9/29/16.
//  Copyright © 2016 trainingprogram. All rights reserved.
//

import UIKit

class ListCellTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
